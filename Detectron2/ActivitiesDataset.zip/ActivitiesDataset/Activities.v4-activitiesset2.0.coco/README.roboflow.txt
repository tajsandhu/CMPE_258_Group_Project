
Activities - v4 ActivitiesSet2.0
==============================

This dataset was exported via roboflow.ai on April 28, 2021 at 11:20 PM GMT

It includes 270 images.
Activities are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit (white edges))

No image augmentation techniques were applied.


